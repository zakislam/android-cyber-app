package com.example.cyber_app_v7;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Concepts extends AppCompatActivity {
    private int[] Images = new int[]{R.drawable.drm, R.drawable.pss, R.drawable.steg, R.drawable.set, R.drawable.tfa, R.drawable.disk,R.drawable.encryptionofcommunicationdata, R.drawable.legal, R.drawable.cha};
    TextView placeholder;
    TextView topicholder;
    ImageView image;
    String Value;
    String information;
    Button button1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_concepts);

        getSupportActionBar().setTitle("QL 128");
        placeholder = (TextView) findViewById(R.id.text);
        Value = (getIntent().getStringExtra("data"));
        image = (ImageView) findViewById(R.id.image1);
        topicholder = (TextView) findViewById(R.id.topic);
        button1 = (Button) findViewById(R.id.back);

        String[] conceptinfo = getResources().getStringArray(R.array.concept_information);

        assert Value != null;
        if (Value.equals("DRM")){
            information = conceptinfo[0];
            placeholder.setText(information);
            topicholder.setText(Value);
            Drawable d = getResources().getDrawable(Images[0]);
            image.setImageDrawable(d);
        }

        else if (Value.equals("Password storing and salts")){
            information = conceptinfo[1];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[1]);
            image.setImageDrawable(d);
        }

        else if (Value.equals("Obfuscation and Steganography")){
            information = conceptinfo[2];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[2]);
            image.setImageDrawable(d);
        }

        else if (Value.equals("Secure transactions")){
            information = conceptinfo[3];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[3]);
            image.setImageDrawable(d);
        }

        else if (Value.equals("Two-factor authentication")){
            information = conceptinfo[4];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[4]);
            image.setImageDrawable(d);
        }

        else if (Value.equals("Disk encryption")){
            information = conceptinfo[5];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[5]);
            image.setImageDrawable(d);
        }

        else if (Value.equals("Encryption of communication data")){
            information = conceptinfo[6];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[6]);
            image.setImageDrawable(d);
        }

        else if (Value.equals("Legal and ethical uses of encryption of data")){
            information = conceptinfo[7];
            placeholder.setText(information);
            topicholder.setText(Value);
            Drawable d = getResources().getDrawable(Images[7]);
            image.setImageDrawable(d);
        }

        else if (Value.equals("Computational hardness assumption")){
            information = conceptinfo[8];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[8]);
            image.setImageDrawable(d);
        }

        else{
            placeholder.setText("Please select a valid option");
        }

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Concepts.this, HomePage.class);
                startActivity(intent);
            }
        });
    }
}
