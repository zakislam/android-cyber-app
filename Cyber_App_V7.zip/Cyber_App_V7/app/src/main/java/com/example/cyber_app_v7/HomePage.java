package com.example.cyber_app_v7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class HomePage extends AppCompatActivity {
    Spinner spinner1;
    Spinner spinner2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        getSupportActionBar().setTitle("QL 128");

        spinner1 =(Spinner) findViewById(R.id.spinner1);
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this, R.array.Cryptography_Concepts, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter1);

        getSupportActionBar().setTitle("Homepage");
        spinner2 = (Spinner)findViewById(R.id.spinner2);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.Cryptography_methods, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter2);

        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                if (position == 1)
                {
                    Intent intent = new Intent(HomePage.this, Concepts.class);
                    intent.putExtra("data",String.valueOf(spinner1.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 2)
                {
                    Intent intent = new Intent(HomePage.this, Concepts.class);
                    intent.putExtra("data",String.valueOf(spinner1.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 3)
                {
                    Intent intent = new Intent(HomePage.this, Concepts.class);
                    intent.putExtra("data",String.valueOf(spinner1.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 4)
                {
                    Intent intent = new Intent(HomePage.this, Concepts.class);
                    intent.putExtra("data",String.valueOf(spinner1.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 5)
                {
                    Intent intent = new Intent(HomePage.this, Concepts.class);
                    intent.putExtra("data",String.valueOf(spinner1.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 6)
                {
                    Intent intent = new Intent(HomePage.this, Concepts.class);
                    intent.putExtra("data",String.valueOf(spinner1.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 7)
                {
                    Intent intent = new Intent(HomePage.this, Concepts.class);
                    intent.putExtra("data",String.valueOf(spinner1.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 8)
                {
                    Intent intent = new Intent(HomePage.this, Concepts.class);
                    intent.putExtra("data",String.valueOf(spinner1.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 9)
                {
                    Intent intent = new Intent(HomePage.this, Concepts.class);
                    intent.putExtra("data",String.valueOf(spinner1.getSelectedItem()));
                    startActivity(intent);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {

            }
        });

        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                if (position == 1)
                {
                    Intent intent = new Intent(HomePage.this, Method.class);
                    intent.putExtra("data",String.valueOf(spinner2.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 2)
                {
                    Intent intent = new Intent(HomePage.this, Method.class);
                    intent.putExtra("data",String.valueOf(spinner2.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 3)
                {
                    Intent intent = new Intent(HomePage.this, Method.class);
                    intent.putExtra("data",String.valueOf(spinner2.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 4)
                {
                    Intent intent = new Intent(HomePage.this, Method.class);
                    intent.putExtra("data",String.valueOf(spinner2.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 5)
                {
                    Intent intent = new Intent(HomePage.this, Method.class);
                    intent.putExtra("data",String.valueOf(spinner2.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 6)
                {
                    Intent intent = new Intent(HomePage.this, Method.class);
                    intent.putExtra("data",String.valueOf(spinner2.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 7)
                {
                    Intent intent = new Intent(HomePage.this, Method.class);
                    intent.putExtra("data",String.valueOf(spinner2.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 8)
                {
                    Intent intent = new Intent(HomePage.this, Method.class);
                    intent.putExtra("data",String.valueOf(spinner2.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 9)
                {
                    Intent intent = new Intent(HomePage.this, Method.class);
                    intent.putExtra("data",String.valueOf(spinner2.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 10)
                {
                    Intent intent = new Intent(HomePage.this, Method.class);
                    intent.putExtra("data",String.valueOf(spinner2.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 11)
                {
                    Intent intent = new Intent(HomePage.this, Method.class);
                    intent.putExtra("data",String.valueOf(spinner2.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 12)
                {
                    Intent intent = new Intent(HomePage.this, Method.class);
                    intent.putExtra("data",String.valueOf(spinner2.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 13)
                {
                    Intent intent = new Intent(HomePage.this, Method.class);
                    intent.putExtra("data",String.valueOf(spinner2.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 14)
                {
                    Intent intent = new Intent(HomePage.this, Method.class);
                    intent.putExtra("data",String.valueOf(spinner2.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 15)
                {
                    Intent intent = new Intent(HomePage.this, Method.class);
                    intent.putExtra("data",String.valueOf(spinner2.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 16)
                {
                    Intent intent = new Intent(HomePage.this, Method.class);
                    intent.putExtra("data",String.valueOf(spinner2.getSelectedItem()));
                    startActivity(intent);
                }

                if (position == 17)
                {
                    Intent intent = new Intent(HomePage.this, Method.class);
                    intent.putExtra("data",String.valueOf(spinner2.getSelectedItem()));
                    startActivity(intent);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {

            }
        });


    }
}
