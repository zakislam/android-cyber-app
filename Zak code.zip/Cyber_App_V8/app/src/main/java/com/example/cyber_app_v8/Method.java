package com.example.cyber_app_v8;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Method extends AppCompatActivity {
    private int[] Images ={R.drawable.shift, R.drawable.onetime, R.drawable.hash, R.drawable.block, R.drawable.stream, R.drawable.cryptographicprim, R.drawable.cryptographicsalts, R.drawable.encryptionalgorithms, R.drawable.prime, R.drawable.symmetrickey, R.drawable.publickey, R.drawable.key_exchange, R.drawable.digitalc, R.drawable.https, R.drawable.vpn, R.drawable.gre, R.drawable.wifi };
    TextView placeholder;
    TextView topicholder;
    TextView imgholder;
    ImageView image;
    String Value;
    String information;
    String img_info;
    Button button1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_method);

        placeholder = (TextView) findViewById(R.id.text);
        Value = (getIntent().getStringExtra("data"));
        image = (ImageView) findViewById(R.id.image1);
        topicholder = (TextView) findViewById(R.id.topic);
        imgholder = (TextView) findViewById(R.id.imgref);
        button1 = (Button) findViewById(R.id.back);

        String[] methodinfo = getResources().getStringArray(R.array.method_information);
        String[] refinfo = getResources().getStringArray(R.array.image_reference_method);

        assert Value != null;
        if (Value.equals("Shift ciphers")){
            information=methodinfo[0];
            placeholder.setText(information);
            topicholder.setText(Value);
            Drawable d = getResources().getDrawable(Images[0]);
            image.setImageDrawable(d);
            img_info = refinfo[0];
            imgholder.setText(img_info);
        }

        else if (Value.equals("One-time pads")){
            information=methodinfo[1];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[1]);
            image.setImageDrawable(d);
            img_info = refinfo[1];
            imgholder.setText(img_info);
        }

        else if (Value.equals("Hash functions (e.g. MD4, MD5, SHA-2 and SHA-3)")){
            information=methodinfo[2];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[2]);
            image.setImageDrawable(d);
            img_info = refinfo[2];
            imgholder.setText(img_info);
        }

        else if (Value.equals("Block ciphers")){
            information=methodinfo[3];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[3]);
            image.setImageDrawable(d);
            img_info = refinfo[3];
            imgholder.setText(img_info);

        }

        else if (Value.equals("Steam ciphers")){
            information=methodinfo[4];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[4]);
            image.setImageDrawable(d);
            img_info = refinfo[4];
            imgholder.setText(img_info);
        }
        else if (Value.equals("Cryptography primitives")){
            information=methodinfo[5];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[5]);
            image.setImageDrawable(d);
            img_info = refinfo[5];
            imgholder.setText(img_info);
        }

        else if (Value.equals("Cryptography salts and their use in strong passwords")){
            information=methodinfo[6];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[6]);
            image.setImageDrawable(d);
            img_info = refinfo[6];
            imgholder.setText(img_info);
        }

        else if (Value.equals("Encryption algorithms")){
            information=methodinfo[7];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[7]);
            image.setImageDrawable(d);
            img_info = refinfo[7];
            imgholder.setText(img_info);
        }

        else if (Value.equals("Mathematical principles")){
            information=methodinfo[8];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[8]);
            image.setImageDrawable(d);
            img_info = refinfo[8];
            imgholder.setText(img_info);
        }

        else if (Value.equals("Symmetric key encryption")){
            information=methodinfo[9];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[9]);
            image.setImageDrawable(d);
            img_info = refinfo[9];
            imgholder.setText(img_info);
        }

        else if (Value.equals("Public key encryption")){
            information=methodinfo[10];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[10]);
            image.setImageDrawable(d);
            img_info = refinfo[10];
            imgholder.setText(img_info);
        }

        else if (Value.equals("Key exchanges")){
            information=methodinfo[11];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[11]);
            image.setImageDrawable(d);
            img_info = refinfo[11];
            imgholder.setText(img_info);
        }

        else if (Value.equals("Digital certificates")){
            information=methodinfo[12];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[12]);
            image.setImageDrawable(d);
            img_info = refinfo[12];
            imgholder.setText(img_info);
        }

        else if (Value.equals("HTTPS protocol")){
            information=methodinfo[13];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[13]);
            image.setImageDrawable(d);
            img_info = refinfo[13];
            imgholder.setText(img_info);
        }

        else if (Value.equals("Virtual Private Networks VPNs")){
            information=methodinfo[14];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[14]);
            image.setImageDrawable(d);
            img_info = refinfo[14];
            imgholder.setText(img_info);
        }

        else if (Value.equals("Generic Routing Encapsulation GRE")){
            information=methodinfo[15];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[15]);
            image.setImageDrawable(d);
            img_info = refinfo[15];
            imgholder.setText(img_info);
        }

        else if (Value.equals("Encryption of data on WI-FI networks")){
            information=methodinfo[16];
            topicholder.setText(Value);
            placeholder.setText(information);
            Drawable d = getResources().getDrawable(Images[16]);
            image.setImageDrawable(d);
            img_info = refinfo[16];
            imgholder.setText(img_info); //this has gre
        }

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Method.this, HomePage.class);
                startActivity(intent);
            }
        });
    }
}
